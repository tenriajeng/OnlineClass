module.exports = {
  getMenu: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  },
  postMenu: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  },
  updateMenu: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  },
  updateMenuImg: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  },
  deleteMenu: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  },
  postTransaction: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  },
  postTransactionMenu: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  },
  getTransaction: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  },
  getTransactionMenu: (res, response, status) => {
    const form = {
      status, // status: status
      response
    };
    res.json(form);
  }
};
